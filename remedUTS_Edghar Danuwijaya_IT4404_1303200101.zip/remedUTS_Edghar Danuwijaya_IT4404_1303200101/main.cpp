#include <iostream>
/*Nama : Edghar Danuwijaya
  Kelas : IT-44-04
  Nim : 1303200101
                   */
using namespace std;
#include "remedSLL.h"

List L;
address P, temp;
infotype DATA;

int main()
{
    createList(L);
    printList(L);

    DATA = newData("Ronaldo", "Tetap");
    P = newElement (DATA);
    insertFirst(L, P);

    DATA = newData ("Alves", "Kontrak");
    P = newElement (DATA);
    insertLast(L, P);

    DATA = newData ("Puyol", "Tetap");
    P = newElement (DATA);
    insertLast(L, P);

    DATA = newData ("Rodrigo", "Kontrak");
    P = newElement (DATA);
    insertLast(L, P);

    printList(L);
    cout<<endl;

    deleteFirst(L, temp);
    deleteLast(L, temp);
    printList(L);
    cout<<endl;
}
