#include "remedSLL.h"
/*Nama : Edghar Danuwijaya
  Kelas : IT-44-04
  Nim : 1303200101
                    */
void createList(List &L) {
    first(L) = NULL;
}

infotype newData(string nama, string status) {
    infotype dta;
    dta.nama = nama;
    dta.status = status;
    return dta;
}

address newElement(infotype dataBaru) {
    address  p = new elmList;
    info(p) = dataBaru;
    next(p) = NULL;
    return p;
}

void insertFirst(List &L, address p) {
    if (first(L) == NULL) {
        first(L) = p;
    }
    else {
        next(p) = first(L);
        first(L) = p;
    }
}

void insertLast(List &L, address p){
    address q;
    if (first(L) == NULL) {
        first(L) = p;
    }
    else {
        q = first(L);
        while (next(q) != NULL) {
            q = next(q);
        }
        next(q) = p;
    }
}

void deleteFirst(List &L, address p) {
    p = first(L);
    if (next(first(L)) == NULL) {
        first(L) = NULL;
    }
    else {
        first(L) = (next(first(L)));
    }
    next(p) = NULL;
}

void printList(List L) {
    address P;
    int i;
    if (first(L) == NULL) {
        cout << "List Kosong" <<endl;
        cout<<endl;
    }
    else {
        i = 1;
        P = first(L);
        while(P != NULL){
            cout<<"ID : "<<i<<endl;
            cout<<"Nama : "<<info(P).nama<<endl;
            cout<<"Status : "<<info(P).status<<endl;
            cout<<endl;
            P = next(P);
            i = i+1;
        }
        cout<<endl;
        cout<<"List selesai ditampilkan!"<<endl;
    }
}

void deleteLast(List &L,address p){
    address q;
    if (first(L) == NULL) {
        p = NULL;
        cout << "List Kosong" << endl;
    }
    else if (next(first(L)) == NULL) {
        p = first(L);
        first(L) = NULL;
    }
    else {
        q = first(L);
        p = first(L);
        while (next(p) != NULL) {
            q = p;
            p = next(p);
        }
        next(q) = NULL;
    }
}
