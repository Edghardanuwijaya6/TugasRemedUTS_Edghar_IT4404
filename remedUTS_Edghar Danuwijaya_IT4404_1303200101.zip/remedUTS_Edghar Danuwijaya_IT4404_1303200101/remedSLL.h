#ifndef REMEDSLL_H_INCLUDED
#define REMEDSLL_H_INCLUDED

#include <iostream>
#include<string>
/*Nama : Edghar Danuwijaya
  Kelas : IT-44-04
  Nim : 1303200101
                   */
using namespace std;

#define info(P) (P)->info
#define next(P) (P)->next
#define first(L) ((L).first)

struct data {
    string nama, status;
};

typedef data infotype;
typedef struct elmList *address;

struct elmList{
    infotype info;
    address next;
};

struct List{
    address first;
};

void createList(List &L);
infotype newData(string nama, string status);
address newElement(infotype dataBaru);
void insertFirst(List &L, address p);
void insertLast(List &L, address p);
void deleteFirst(List &L, address p);
void deleteLast(List &L, address p);
void printList(List L);


#endif // REMEDSLL_H_INCLUDED
